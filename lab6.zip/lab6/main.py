import requests
from bs4 import BeautifulSoup
from collections import defaultdict
from bs4.element import Comment


def visible_tag(element):
    if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
        return False
    if isinstance(element, Comment):
        return False
    return True


def get_data(url):
    tags_data = defaultdict(int)
    words_data = defaultdict(int)

    request = requests.get(url)
    page = BeautifulSoup(request.text, 'html.parser')
    for tag in page.find_all():
        tags_data[tag.name] += 1
    tags = {k: v for k, v in sorted(tags_data.items(), key=lambda item: item[1], reverse=True)}
    count_of_links = tags['a'] if 'a' in tags else 0
    count_of_images = tags['img'] if 'img' in tags else 0
    texts = page.findAll(text=True)
    visible_texts = filter(visible_tag, texts)
    text = u" ".join(t.strip() for t in visible_texts) \
        .replace(',', ' ') \
        .replace('.', ' ') \
        .replace('!', ' ') \
        .replace('-', ' ').split(' ')
    data = list(filter(None, text))
    for word in data:
        words_data[word.lower()] += 1
    words = {k: v for k, v in sorted(words_data.items(), key=lambda item: item[1], reverse=True)}
    return tags, count_of_links, count_of_images, words


if __name__ == '__main__':
    tags, count_of_links, count_of_images, words = get_data('https://portal.lviv.ua/news/2021/12/10/u-tsentri-lvova-pid-chas-rukhu-zahorivsia-elektrovelosyped')

    print('=== TAGS INFO ===')
    for i, tag in enumerate(tags):
        print(f'#{i + 1} - {tag} : {tags[tag]}')

    print(f'=== LINKS AND IMAGES INFO ===\n Links - {count_of_links}\n Images - {count_of_images}')

    print('=== WORDS INFO ===')
    for i, word in enumerate(words):
        print(f'#{i + 1} - {word} : {words[word]}')
