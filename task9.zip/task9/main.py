import re
from tabulate import tabulate
import pandas as pd
import json
import matplotlib.pyplot as plt
import numpy as np


def to_float(string: str):
    return float(string.replace(' ', '').replace(',', '.'))


def parse_data(file, regex):
    return_data = []
    with open(file, 'r') as file:
        for line in file.readlines():
            return_data.append(list(re.findall(regex, line)[0]))
    return return_data


def get_table(data, headers):
    return tabulate(data, headers=headers, tablefmt='orgtbl')


def merge_data(movement, directory):
    for i, element in enumerate(movement):
        movement[i] += list(filter(lambda x: x[0] == element[0], directory))[0][1:]
    return sorted(movement, key=lambda x: x[0])


def save_to_txt(file, data, headers):
    with open(file + ".txt", 'w') as file:
        file.write(get_table(data, headers))


def save_to_exel(file, data, headers):
    def __data_to_dict():
        return_dict = {i: [] for i in headers}
        for element in data:
            for key, value in zip(headers, element):
                return_dict[key].append(value)
        return return_dict

    df = pd.DataFrame(__data_to_dict())
    writer = pd.ExcelWriter(file + '.xlsx', engine='xlsxwriter')
    df.to_excel(writer, sheet_name='Sheet1')
    writer.save()


def save_json(file, data, headers):
    return_data = []
    for element in data:
        return_data.append({key: value for key, value in zip(headers, element)})
    with open(file + '.json', 'w', encoding='utf8') as outfile:
        json.dump(return_data, outfile, indent=4, ensure_ascii=False)


def show_plot(data):
    labels = ['Тканини', 'Одяг та білизна', 'Взуття', 'Трикотаж', 'Галантерея']
    years = {'2013': [], '2014': [], '2015': []}

    for element in data:
        years[element[3]].append(element[1])
    x = np.arange(len(labels))
    width = 0.35

    fig, ax = plt.subplots()

    zal1 = ax.bar(x - width, years['2013'], width, label='2013')
    nad1 = ax.bar(x, years['2014'], width, label='2014')
    vub1 = ax.bar(x + width, years['2015'], width, label='2015')

    ax.set_xticks(x, labels, rotation=90)
    ax.legend()

    ax.bar_label(zal1, padding=3)
    ax.bar_label(nad1, padding=3)
    ax.bar_label(vub1, padding=3)

    fig.tight_layout()

    plt.show()


if __name__ == '__main__':
    department_store_turnover_headers = ['Код товарної групи', 'План', 'Очікуємевиконання', 'Рік']
    department_store_turnover = parse_data('input/department_store_turnover.txt', r'(.*)	(.*)	(.*)	(.*)')

    handbook_of_product_groups_headers = ['Код товарної групи', 'Найменування товарної групи', 'Торгова скидка, %']
    handbook_of_product_groups = parse_data('input/handbook_of_product_groups.txt', r'(.*)	(.*)	(.*)')

    print(get_table(department_store_turnover, department_store_turnover_headers), end="\n\n")
    print(get_table(handbook_of_product_groups, handbook_of_product_groups_headers), end="\n\n")

    merge_headers = [*department_store_turnover_headers, *handbook_of_product_groups_headers[1:]]
    merged_data = merge_data(department_store_turnover, handbook_of_product_groups)

    print(get_table(merged_data, merge_headers))

    save_to_txt('merge', merged_data, merge_headers)

    save_to_exel('merge', merged_data, merge_headers)

    save_json('merge', merged_data, ['KODT', 'TOP', 'TOO', 'GOD', 'NAMET', 'TSKI'])

    show_plot(merged_data)
